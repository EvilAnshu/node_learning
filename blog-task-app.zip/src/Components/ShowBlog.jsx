import React, { Component } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import './styles/showBlog.css';

class ShowNavi extends Component {

    constructor() {
        super();
        this.state = {
            title: "",
            desc: "",
            users: []
        }
    }
    componentDidMount() {
        fetch("http://localhost:5000/posts", {
            method: "GET"
        }).then((resp) => {
            return resp.json();
        }).then((dt) => {
            if (Array.isArray(dt)) {
                this.setState({
                    users: dt
                })
            }
        }).catch((error) => {
            console.log(error);
        })
    }
    showPage = (item) => {
        // console.log(item)
        this.props.navigate("/Detail#" + item.slug, { state: { item: item } })
    }
    getData = () => {
        if (this.state.users.length == 0) {
            return "No Data Found";
        }
        else
            return (this.state.users.map((item, index) => {
                return (<>

                    <div className="col-lg-4">
                        <div className="card card-margin">
                            <div className="card-header no-border">
                                <div><h5 className="card-title">{item.title}</h5></div>
                                <div><input type="button" onClick={() => { this.showPage(item) }} value="View" className="btn btn-outline-success a" /></div>
                            </div>
                            <div className="card-body pt-0">
                                <div className="widget-49">
                                    <div className="widget-49-title-wrapper">

                                        <div className="widget-49-meeting-info">
                                            {/* <span className="widget-49-pro-title">PRO-08235 DeskOpe. Website</span> */}
                                            <span className="widget-49-meeting-time">{item.date}</span>
                                        </div>
                                    </div>

                                    {/* <div className="widget-49-meeting-action">
                                            <input type="button" onClick={() => { this.showPage(item) }} value="View" className="btn btn-outline-success a"/>
                                        </div> */}
                                </div>
                            </div>
                        </div>
                    </div>


                </>
                )
            }))
    }
    render() {
        return (
            <>
                <div className="container">

                    <div className="row mt-4">
                        {this.getData()}
                    </div>
                </div>

            </>
        );
    }
}
export function ShowBlog() {
    const navigate = useNavigate();
    // console.log(location.state.id)
    return <ShowNavi navigate={navigate} />
}

export default ShowBlog;